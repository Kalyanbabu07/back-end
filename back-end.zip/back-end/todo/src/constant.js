const DBName = "todo-db"

export default DBName